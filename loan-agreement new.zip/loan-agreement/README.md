# loan agreement

A Pen created on CodePen.io. Original URL: [https://codepen.io/Aspire-to-succeed-Aspire-to-succeed/pen/VwJEMPy](https://codepen.io/Aspire-to-succeed-Aspire-to-succeed/pen/VwJEMPy).

